package linkedList;

public class SLLNode {
	Object element;
	SLLNode next;
	SLLNode prev;
	
	public SLLNode(Object element, SLLNode next)
	{
		this.element = element;
		this.next = next;
	}
}
